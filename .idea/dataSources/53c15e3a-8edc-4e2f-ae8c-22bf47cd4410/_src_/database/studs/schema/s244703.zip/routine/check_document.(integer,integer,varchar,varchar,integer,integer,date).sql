create function check_document(id_person integer, id_document_type integer, name character varying, surname character varying, passport integer, country integer, birth_date date) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
document_type_name varchar = (SELECT ДОКУМЕНТ FROM ВИДЫ_ДОКУМЕНТОВ WHERE ИД = id_document_type);
document_id int = get_document_id(id_person, document_type_name);
BEGIN
IF document_id <0  THEN
RETURN FALSE;
END IF;
IF document_type_name = 'ВХОДНОЙ БИЛЕТ'  THEN
RETURN check_entry_ticket(document_id);
END IF;
IF document_type_name = 'ИД КАРТОЧКА'  THEN
RETURN check_id_card(id_person, document_id);
END IF;
IF document_type_name = 'ПАСПОРТ'  THEN
RETURN check_passport(id_person, document_id);
END IF;
IF document_type_name = 'УБЕЖИЩЕ'  THEN
RETURN check_asylum(id_person, document_id, name,surname,passport,country, birth_date);
END IF;
IF document_type_name = 'РАЗРЕШЕНИЕ НА ВЪЕЗД'  THEN
RETURN check_accept_enter(id_person, document_id, name,surname,passport);
END IF;
IF document_type_name = 'ВИЗА НА ВЪЕЗД'  THEN
RETURN check_accept_country(id_person, document_id, name,surname,passport,country);
END IF;
IF document_type_name = 'УДОСТОВЕРЕНИЕ ЛИЧНОСТИ'  THEN
RETURN check_country_card(id_person, document_id, name,surname,passport,birth_date);
END IF;
RETURN FALSE;
END;
$$;

create function get_document_id(id_person integer, document_name character varying) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
document_type_id int = (SELECT ИД FROM ВИДЫ_ДОКУМЕНТОВ WHERE ДОКУМЕНТ = document_name);
cur_date date = (SELECT current_date);
document_id int = (SELECT ИД_ДОКУМЕНТА FROM НАЛИЧИЕ_ДОКУМЕНТОВ WHERE ИД_ЧЕЛОВЕКА = id_person
AND ДАТА_ВИЗИТА = cur_date AND ИД_ДОКУМЕНТА IN (SELECT ИД FROM ДОКУМЕНТЫ WHERE ИД_ВИДА = document_type_id));
BEGIN
IF document_id = null  THEN
RETURN -1;
END IF;
RETURN document_id;
END;
$$;

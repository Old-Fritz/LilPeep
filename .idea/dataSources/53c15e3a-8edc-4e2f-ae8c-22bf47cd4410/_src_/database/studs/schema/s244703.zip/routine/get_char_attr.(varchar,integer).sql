create function get_char_attr(text character varying, id_document integer) returns character varying
LANGUAGE plpgsql
AS $$
DECLARE
id_attr int = (SELECT ИД FROM ТИПЫ_ДОП_ХАРАКТЕРИСТИК WHERE НАЗВАНИЕ = text);
attr varchar = (SELECT ЗНАЧЕНИЕ FROM ДОП_ХАРАКТЕРИСТИКИ WHERE ИД_ДОКУМЕНТА = id_document AND ИД_ВИДА_ХАРАКТЕРСТИКИ = id_attr);
BEGIN
RETURN attr;
END;
$$;

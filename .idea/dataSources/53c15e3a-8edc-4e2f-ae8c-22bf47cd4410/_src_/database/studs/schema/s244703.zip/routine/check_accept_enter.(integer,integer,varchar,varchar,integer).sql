create function check_accept_enter(id_person integer, id_document integer, name character varying, surname character varying, passport integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
pers_purpose int = (SELECT ИД_ЦЕЛИ_ВИЗИТА FROM ЧЕЛОВЕК WHERE ИД = id_person);
pers_interval int = (SELECT ПРОДОЛЖИТЕЛЬНОСТЬ FROM ЧЕЛОВЕК WHERE ИД = id_person);
cur_date date = (SELECT current_date);
entry_date date = (SELECT ДАТА_ИСТЕЧЕНИЯ FROM ДОКУМЕНТЫ WHERE ИД = id_document);
doc_name varchar = (SELECT ИМЯ FROM ДОКУМЕНТЫ WHERE ИД = id_document);
doc_surname varchar = (SELECT ФАМИЛИЯ FROM ДОКУМЕНТЫ WHERE ИД = id_document);
doc_passport int = (SELECT НОМЕР_ПАСПОРТА FROM ДОКУМЕНТЫ WHERE ИД = id_document);
doc_purpose int = (SELECT ИД_ЦЕЛИ_ВИЗИТА FROM ДОКУМЕНТЫ WHERE ИД = id_document);
doc_interval int = (SELECT ПРОДОЛЖИТЕЛЬНОСТЬ FROM ДОКУМЕНТЫ WHERE ИД = id_document);
BEGIN
IF entry_date < cur_date  THEN
RETURN false;
END IF;
IF doc_purpose != pers_purpose  THEN
RETURN false;
END IF;
IF pers_interval != doc_interval  THEN
RETURN false;
END IF;
IF name != doc_name  THEN
RETURN false;
END IF;
IF surname != doc_surname  THEN
RETURN false;
END IF;
IF passport != doc_passport  THEN
RETURN false;
END IF;
RETURN true;
END;
$$;

create function get_int_attr(text character varying, id_document integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
id_attr int = (SELECT ИД FROM ТИПЫ_ДОП_ХАРАКТЕРИСТИК WHERE НАЗВАНИЕ = text);
attr int = (SELECT CAST(ЗНАЧЕНИЕ AS integer) FROM ДОП_ХАРАКТЕРИСТИКИ WHERE ИД_ДОКУМЕНТА = id_document AND ИД_ВИДА_ХАРАКТЕРСТИКИ = id_attr);
BEGIN
RETURN attr;
END;
$$;

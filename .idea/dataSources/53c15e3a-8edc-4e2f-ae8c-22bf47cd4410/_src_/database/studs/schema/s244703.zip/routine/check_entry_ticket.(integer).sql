create function check_entry_ticket(id_document integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
cur_date date = (SELECT current_date);
entry_date date = (SELECT ДАТА_ИСТЕЧЕНИЯ FROM ДОКУМЕНТЫ WHERE ИД = id_document);
BEGIN
IF entry_date < cur_date THEN
RETURN false;
END IF;
RETURN true;
END;
$$;

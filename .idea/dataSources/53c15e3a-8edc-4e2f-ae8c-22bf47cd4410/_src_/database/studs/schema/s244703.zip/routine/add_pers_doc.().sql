create function add_pers_doc() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
cur_date date = (SELECT current_date);
BEGIN
NEW.ДАТА_ВИЗИТА = cur_date;
RETURN NEW;
END;
$$;

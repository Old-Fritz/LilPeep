create function check_id_card(id_person integer, id_document integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
pers_weight int = (SELECT ВЕС FROM ЧЕЛОВЕК WHERE ИД = id_person);
pers_height int = (SELECT РОСТ FROM ЧЕЛОВЕК WHERE ИД = id_person);
pers_fingers int = (SELECT ИД_ОТПЕЧАТКОВ FROM ЧЕЛОВЕК WHERE ИД = id_person);
cur_date date = (SELECT current_date);
entry_date date = (SELECT ДАТА_ИСТЕЧЕНИЯ FROM ДОКУМЕНТЫ WHERE ИД = id_document);
doc_weight int = (SELECT ВЕС FROM ДОКУМЕНТЫ WHERE ИД = id_document);
doc_height int = (SELECT РОСТ FROM ДОКУМЕНТЫ WHERE ИД = id_document);
doc_fingers int = (SELECT ИД_ОТПЕЧАТКОВ FROM ДОКУМЕНТЫ WHERE ИД = id_document);
BEGIN
IF entry_date < cur_date  THEN
RETURN false;
END IF;
IF pers_weight != doc_weight  THEN
RETURN false;
END IF;
IF pers_fingers != doc_fingers  THEN
RETURN false;
END IF;
IF pers_height != doc_height  THEN
RETURN false;
END IF;
RETURN true;
END;
$$;

create function check_passport(id_person integer, id_document integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
pers_photo int = (SELECT ИД_ФОТО FROM ЧЕЛОВЕК WHERE ИД = id_person);
pers_gender int = (SELECT ПОЛ FROM ЧЕЛОВЕК WHERE ИД = id_person);
cur_date date = (SELECT current_date);
entry_date date = (SELECT ДАТА_ИСТЕЧЕНИЯ FROM ДОКУМЕНТЫ WHERE ИД = id_document);
birth_date date = (SELECT ДАТА_РОЖДЕНИЯ FROM ДОКУМЕНТЫ WHERE ИД = id_document);
doc_photo int = (SELECT ИД_ФОТО FROM ДОКУМЕНТЫ WHERE ИД = id_document);
doc_gender int = get_char_attr('ПОЛ', id_document);
doc_city int = get_int_attr('ГОРОД', id_document);
doc_country int = (SELECT ИД_СТРАНЫ FROM ДОКУМЕНТЫ WHERE ИД = id_document);
BEGIN
IF entry_date < cur_date  THEN
RETURN false;
END IF;
IF birth_date > cur_date  THEN
RETURN false;
END IF;
IF pers_photo != doc_photo  THEN
RETURN false;
END IF;
IF pers_gender != doc_gender  THEN
RETURN false;
END IF;
IF !check_country(doc_city, doc_country)  THEN
RETURN false;
END IF;
RETURN true;
END;
$$;

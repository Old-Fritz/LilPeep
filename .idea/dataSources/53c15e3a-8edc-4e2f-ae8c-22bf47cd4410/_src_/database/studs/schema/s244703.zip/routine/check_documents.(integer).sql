create function check_documents(id_person integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
passport_id int = get_document_id(id_person, 'ПАСПОРТ');
doc_name varchar = (SELECT ИМЯ FROM ДОКУМЕНТЫ WHERE ИД = passport_id);
doc_surname varchar = (SELECT ФАМИЛИЯ FROM ДОКУМЕНТЫ WHERE ИД = passport_id);
doc_birth_date date = (SELECT ДАТА_РОЖДЕНИЯ FROM ДОКУМЕНТЫ WHERE ИД = passport_id);
doc_country int = (SELECT ИД_СТРАНЫ FROM ДОКУМЕНТЫ WHERE ИД = passport_id);
doc_passport_num  int = (SELECT НОМЕР_ПАСПОРТА FROM ДОКУМЕНТЫ WHERE ИД = passport_id);
document_type_id int;
check_result boolean;
BEGIN
FOR document_type_id IN (SELECT ИД_ВИДА_ДОКУМЕНТА FROM ТРЕБОВАНИЯ WHERE ИД_СТРАНЫ = doc_country) LOOP
        check_result = check_document(id_person, document_type_id, doc_name, doc_surname, doc_passport_num, doc_country, doc_birth_date);
IF check_result != TRUE THEN
RETURN FALSE;
END IF;
    END LOOP;
RETURN TRUE;
END;
$$;

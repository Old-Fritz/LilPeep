create function add_to_history() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
cur_date date = (SELECT current_date);
BEGIN
IF check_documents(NEW.ИД_ЧЕЛОВЕКА) THEN
NEW.ПРОПУЩЕН = TRUE;
END IF;
NEW.ВРЕМЯ = cur_date;
RETURN NEW;
END;
$$;

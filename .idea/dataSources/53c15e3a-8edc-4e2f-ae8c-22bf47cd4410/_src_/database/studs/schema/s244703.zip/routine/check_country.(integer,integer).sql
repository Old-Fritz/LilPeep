create function check_country(id_city integer, id_county integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
country int = (SELECT ИД_СТРАНЫ FROM ГОРОДА WHERE ИД = id_city);
BEGIN
IF country != id_county THEN
RETURN false;
END IF;
RETURN true;
END;
$$;
